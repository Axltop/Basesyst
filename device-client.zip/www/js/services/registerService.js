angular.module('starter.services')
  .factory('RegisterService', function () {

  });
