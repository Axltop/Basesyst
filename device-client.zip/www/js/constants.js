/**
 * Created by jumperabg on 15.6.2016 г..
 */
angular.module('starter.constants', [])
  .constant('SERVER_ADDRESS', 'http://192.168.0.104');
